#!/usr/bin/env python3
"""Restaura o HTML original, valida a integridade e evita mudancas ocultas."""
from __future__ import annotations
import gzip
import hashlib
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COMPRESSED = ROOT / "frontend" / "index.html.gz"
OUTPUT = ROOT / "www" / "index.html"
EXPECTED_SHA256 = "6b3817674a35412f8736e0adf0054a4447f027d2e8921fbe870a698c963d9fc2"

def verify(file_path: Path) -> None:
    digest=hashlib.sha256()
    with file_path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            digest.update(chunk)
    got=digest.hexdigest()
    if got != EXPECTED_SHA256:
        raise RuntimeError(f"HTML corrompido ou versao diferente: {got} != {EXPECTED_SHA256}")

def main():
    if not COMPRESSED.exists():
        raise SystemExit("Arquivo frontend/index.html.gz nao encontrado.")
    if OUTPUT.exists():
        try:
            verify(OUTPUT)
            print("HTML ja restaurado e integro.")
            return
        except RuntimeError:
            OUTPUT.unlink()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    tmp=OUTPUT.with_suffix('.html.tmp')
    try:
        with gzip.open(COMPRESSED,'rb') as src, tmp.open('wb') as dest:
            shutil.copyfileobj(src,dest,1024*1024)
        verify(tmp)
        tmp.replace(OUTPUT)
    finally:
        tmp.unlink(missing_ok=True)
    print(f"HTML 18.121 validado e restaurado: {OUTPUT.stat().st_size} bytes")

if __name__ == '__main__':
    main()
