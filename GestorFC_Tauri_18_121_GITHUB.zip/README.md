# Gestor FC Mundo 18.121 — Windows .exe portatil via Tauri

Este repositorio monta um executavel de TESTE Windows x64 usando Tauri 2,
sem gerar instalador MSI ou NSIS. O HTML de origem e a versao 18.121 e nao
recebeu mudancas de logica neste pacote.

## Metodo 1: com Git (recomendado)

1. Crie um repositorio **privado** vazio no GitHub.
2. Extraia o ZIP `GestorFC_Tauri_18_121_GITHUB.zip` para uma pasta no Windows.
3. Envie os arquivos e pastas extraidos para a raiz do repositorio, preservando
   `.github/workflows/build-portable-windows.yml` e `frontend/index.html.gz`.
4. Acesse a aba **Actions**; selecione **Gerar EXE Windows portatil** e clique
   em **Run workflow**.
5. Apos o status verde, abra a execucao; em **Artifacts**, baixe
   `GestorFC-Mundo-v18.121-Windows-portatil`.
6. Extraia o artefato e execute `GestorFC-Mundo-v18.121-PORTATIL.exe` no Windows.

## Metodo 2: somente pelo site do GitHub (sem Git no PC)

1. Crie um repositorio privado com a branch `main`.
2. No repositorio, use **Add file > Upload files** e envie **o ZIP inteiro**
   `GestorFC_Tauri_18_121_GITHUB.zip` para a raiz, sem descompactar.
3. Depois use **Add file > Create new file** e coloque o caminho exato
   `.github/workflows/build-portable-windows.yml`.
4. Abra o arquivo `build-portable-windows.yml` que veio ao lado do ZIP,
   copie seu conteudo e salve/commit no caminho criado.
5. Em **Actions > Gerar EXE Windows portatil > Run workflow**, execute.
6. Baixe o artefato no final. A action extrai o ZIP automaticamente.

**Importante:** o GitHub nao executa o conteudo de um ZIP enviado sozinho.
O arquivo `.github/workflows/build-portable-windows.yml` precisa estar presente
no repositorio, fora do ZIP, no metodo 2.

## Arquitetura

- Windows 10/11 x64. O Microsoft Edge WebView2 Runtime precisa estar presente
  no Windows; normalmente ja vem instalado.
- O HTML e embutido no EXE; nao precisa levar a pasta `frontend` junto.
- A carreira continua salva localmente em IndexedDB, agora no perfil do
  WebView2 deste aplicativo (separado de Chrome/Edge). Salve backups no jogo.
- O acesso ao Supabase requer internet para login e validacao de licenca.
- O novo ambiente WebView2 pode contar como dispositivo adicional no limite
  de licencas Premium.
- Este teste nao inclui assinatura digital do executavel, entao o Windows
  SmartScreen pode exibir aviso de arquivo sem reputacao.
- Tauri NAO garante oficialmente portabilidade universal; neste projeto o
  EXE e distribuido sem instalador e utiliza dependencias do Windows.

## Supabase — validacao da versao HTML

O arquivo mantem o projeto Supabase ja usado pelo jogo, com chave
**publishable** publica e API HTTPS; nao inclui senha ou `service_role`.
O login em `auth/v1/token` utiliza e-mail e senha, e a rotina
`/functions/v1/validate-license` recebe o JWT, checa plano (`free`, `premium`,
`author`), status, vencimento e limite de dispositivos. Os recursos Premium
sao habilitados somente apos validacao com o servidor.

A funcao `validate-license` foi encontrada ATIVA no projeto e usa CORS com
origem `*`, cabecalhos `authorization, apikey, content-type` e metodo `OPTIONS`
para preflight. Ainda e preciso testar autenticar dentro do EXE construido.

## Compilacao no Windows com Rust/Tauri ja instalados

```powershell
python scripts/prepare_frontend.py
cargo install tauri-cli --version 2.12.2 --locked
cargo tauri build --no-bundle --target x86_64-pc-windows-msvc
```

Local do resultado: `src-tauri/target/x86_64-pc-windows-msvc/release/gestor-fc-mundo.exe`.

## Integridade do HTML

Como o HTML tem mais que 25 MB, a fonte foi guardada em `frontend/index.html.gz`
(< 25 MB), evitando o limite de upload pela interface do GitHub. O script
`scripts/prepare_frontend.py` restaura `www/index.html` antes de compilar,
confere SHA-256 e falha se os dados forem modificados/corrompidos.

- SHA-256 do HTML 18.121: `6b3817674a35412f8736e0adf0054a4447f027d2e8921fbe870a698c963d9fc2`
- Tamanho do HTML original: 37256889 bytes
- Tamanho comprimido gzip: 17808626 bytes

## Limites deste primeiro teste

Este pacote passou por verificacao estrutural e checagem de integridade local.
A compilacao nativa do Windows ocorre no GitHub Actions, e o jogo nao foi
executado aqui em um computador Windows. O primeiro teste deve cobrir login,
plano, criacao de carreira, salvamento, Worker de ferias e fechamento da temporada.
