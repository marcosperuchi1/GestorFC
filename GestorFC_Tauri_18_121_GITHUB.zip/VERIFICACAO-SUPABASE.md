# Verificacao do Supabase na versao 18.121

A revisao do HTML e do projeto remoto encontrou:

- URL do Supabase e chave **publishable** no HTML (chave para clientes; nenhuma
  `service_role` incorporada).
- Login: `/auth/v1/token?grant_type=password`.
- Recuperacao de sessao: refresh token e nova validacao remota.
- Plano: `/functions/v1/validate-license` recebe access token e device ID.
- Planos aceitos pela interface: `free`, `premium` e `author`.
- A funcao `validate-license` esta ATIVA e consulta `licenses` por `user_id`.
- A tabela `licenses` tem RLS ativo e campos `plan`, `status`, `valid_until`,
  `max_devices`.
- Uma licenca inativa ou vencida retorna `free` efetivo.
- Premium/Autor contabiliza dispositivos autorizados usando o hash do ID.
- Os controles da interface consultam `v548FullAccess()`.
- A restauracao de login local antigo foi desativada, de modo que um campo
  local com `plan=premium` nao e fonte de autorizacao.

Nao foi executado login real com credenciais de usuario no executavel Windows.
A interface Tauri usa o WebView2 e pode usar uma identidade de dispositivo
separada do navegador anterior.
